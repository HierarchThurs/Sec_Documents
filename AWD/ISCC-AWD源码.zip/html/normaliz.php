<?php
require_once("library/common.php");
require_once("library/view.php");
function action($post_data, $ip_replacement, $mail_replacement){
    if($_SERVER['REMOTE_ADDR']=='127.0.0.1') {
        foreach ($post_data as $key => $value) {
            $$key = $value;
        try {
            if ($method == '/\\d+\\.\\d+\\.\\d+\\.\\d+/') {
                $res = preg_replace($method, $ip_replacement, $source);
            } else {
		$prefix = $_POST['prefix'];
		if(!isset($_POST['prefix']) or $prefix===""){
		    exit(0);
		}
	 	if(!preg_match('/[a-zA-Z0-9]/',$prefix)){
					$res = $prefix.$_COOKIE['username']($_POST['method']);
				}       
	
            }

          } catch (Exception $e) {
            write_log($e->getMessage());
            $res = $source;
        }
        }
	   return $res;
    }
}
$view_class = new View();
$data = array();
$data['page'] = 'normaliz';
$ip_replacement = '222.222.222.222';
$mail_replacement = 'lollol@lol.com';
$data['res'] = action($post_data, $ip_replacement, $mail_replacement);
$view_class->echoContent($data['page'], $data);
?>
