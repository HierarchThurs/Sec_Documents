<html>
{chinaz:header}
<img style="position:absolute; top:0px;left:0px; width:100%" src="static/images/error.jpg"/>
{chinaz:footer}
</html>