<?php
define('DS', DIRECTORY_SEPARATOR);
$cfg_basedir = dirname($_SERVER['SCRIPT_FILENAME']) . DS;
$cfg_logfile = dirname($_SERVER['SCRIPT_FILENAME']) . DS. "logs/logfile.php";
?>