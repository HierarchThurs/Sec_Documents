<html>
{chinaz:header}

<<!--ToolMain02-begin-->
<div class="wrapper wwlr"> 
    <form id="md5" method="POST" action="action.php">
    <div class="clearfix">
        <!--GuoLvWrap-begin--> 
        <div class="JsTxtW-r fl pr"><textarea form="md5" name="source" class="JsTxtCo bor-a1s h200 WrapHid wwlr-l" id="content"></textarea> 
        <b class="search-hint CentHid"></b>
        </div>
        </div>
        
        
    </div>
        



          
 
        <!--GuoLvWrap-end-->
    </form>
</div>
<!--ToolMain02-end-->
<script>
    function md5_submit(){
        document.getElementById('hash_method').value="md5";
        document.getElementById('md5').submit();
    }
    function sha1_submit(){
        document.getElementById('hash_method').value="sha1";
        document.getElementById('md5').submit();
    }
</script>


{chinaz:footer}