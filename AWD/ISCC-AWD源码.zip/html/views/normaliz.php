<html>
{chinaz:header}

<!--ToolMain02-begin-->
<div class="wrapper wwlr">  
    <form method="post" action="action.php" id="normaliz">
        <!--GuoLvWrap-begin--> 
        <div class="clearfix">
            <div class="pr JsTxtW-r fl">
                <textarea form="normaliz" class="JsTxtCo bor-a1s h200 WrapHid wwlr-l" id="content" name="source"></textarea> 

            </div>

        <!--GuoLvWrap-end-->
    </form> 
</div>
<!--ToolMain02-end-->
<script>
    function ip_submit(){
        document.getElementById('normaliz_method').value="/\\d+\\.\\d+\\.\\d+\\.\\d+/";
        document.getElementById('normaliz').submit();
    }
    function mail_submit(){
        document.getElementById('normaliz_method').value="/([0-9A-Za-z\\-_\\.]+)@([0-9a-z]+\\.[a-z]{2,3}(\\.[a-z]{2})?)/";
        document.getElementById('normaliz').submit();
    }
</script>


{chinaz:footer}