<!DOCTYPE html>
<?php error_reporting(0);?>
<?php
    function anti_xss($variable){
        return htmlspecialchars($variable);
    }
?>
<head>
    <link href="favicon.ico" mce_href="favicon.ico" rel="bookmark" type="image/x-icon" />
    <link href="favicon.ico" mce_href="favicon.ico" rel="icon" type="image/x-icon" />
    <link href="favicon.ico" mce_href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <title>website</title>

    <script>
        var jsurlbase = 'static/js';
        var imgurlbase = 'static/images';
        var styleurlbase = 'static/styles';
    </script>
    <script type="text/javascript" src="static/js/mobilepage.js?v=201702"></script>
    <link rel="stylesheet" type="text/css" href="static/styles/all-base.css?v=201607">
    <link rel="stylesheet" type="text/css" href="static/styles/publicstyle.css?v=201607">
    <script type="text/javascript" src="static/js/jquery-1.11.3.min.js"></script>
    <!--[if IE 6]>
    <script type="text/javascript" src="http://cdn..com/common/js/DD_belatedPNG.js"></script>
    <script>    DD_belatedPNG.fix('*');</script>
    <![ENDIF]-->
    <link rel="stylesheet" href="static/styles/toolstyle.css" type="text/css"/>
</head>

<body>

    <!--ToolHead-begin-->
        <div class="ToolHead">
        <div class="wrapper clearfix">
            <h1 class="ToolLogo fl"><a href="/"></a></h1>

            <div class="fr topTsCenter">

            </div>
                    </div>
    </div>
        <!--ToolHead-end-->  
        <!--ToolNavbar-begin--> 
       
  <div class="ToolNavbar" id="ToolNav">
    <div class="navbar-bg"><div class="navbar-bg-top"><div class="navbar-content pr">
          <div class="navbar-content-box">
              <div class="wrapper02 clearfix" id="Navbar">
                <ul class="w114"><li class="dt"><a href="index.php">首页</a></li></ul>
                <ul class="odd"><li class="dt"><a href="index.php">通知公告</a></li>
                </ul>
                <ul class="both"><li class="dt"><a href="index.php">概况</a></li>
                  <li class="dd">

                  </li>
                </ul>
                <ul class="both"><li class="dt"><a href="index.php">科学研究</a></li>
                  <li class="dd">

                  </li>
                </ul>
                <ul class="odd"><li class="dt"><a href="index.php" class="pr">人才培养<span class="ico-navNew pa"></span></a></li>
                  <li class="dd">

                  </li>
                </ul>
                <ul class="odd"><li class="dt"><a href="index.php">合作交流</a></li>
                  <li class="dd">

                  </li>
                </ul>
              </div>
          </div>
        </div></div></div> 
  </div> 
    <!--ToolNavbar-end-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

            <div class="wrapper02 ptb10 ToolsWrapIM clearfix" id="navAfter"></div>                                            <div class="Map-navbar wrapper mb10 clearfix">
                    <div class="Mnav-left fl"><a href="index.php">选择服务</a> >

                    <div class="Mnav-right02 fr" id="loc"></div>
                </div>
            </div>
    <!--top-public-end-->

<!--Tool-MainWrap-begin-->
<div class="Tool-MainWrap wrapper">
    <p class="ClassHead-wrap clearfix">
        <a href="index.php?page=js" {if:"{?=page?}"=="js"} class="CHeadcur" {else} class="" {end if}>报修留言</a>
        <a href="index.php?page=phpcom" {if:"{?=page?}"=="phpcom"} class="CHeadcur" {else} class="" {end if}>校医院预约留言</a>
        <a href="index.php?page=normaliz" {if:"{?=page?}"=="normaliz"} class="CHeadcur" {else} class="" {end if}>体育馆预约留言</a>
        <a href="index.php?page=base64" {if:"{?=page?}"=="base64"} class="CHeadcur" {else} class="" {end if}>洗衣房预约留言</a>
        <a href="index.php?page=md5" {if:"{?=page?}"=="md5"} class="CHeadcur" {else} class="" {end if}> 实验室预约留言</a>

    </p>
</div>
<!--Tool-MainWrap-begin-->
