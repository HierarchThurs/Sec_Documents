<!--footer-public-begin-->
<script src="http://stats..com/tool_img/tool_a.js" type="text/javascript"></script>
<script type="text/javascript" src="http://my..com/js/uc.js" charset="utf-8"></script>
<div class="TFloat-item" id="toTop"> 
    <a href="javascript:" id="TFloat" title="回到顶部" style="display:none;"></a> <a href="http://tool..com/contact" class="feedback" target="_blank"></a> <a href="javascript:" class="Record" id="record"></a>
  <div class="Record-show " id="RecordShow" style="display:none;">
    <div class="Tgroup"> 
        <a href="http://seo..com/" target="_blank">SEO查询</a> 
        <a href="http://icp..com/" target="_blank">备案查询</a> 
        <a href="http://ip..com/" target="_blank">IP查询</a> 
        <a href="http://tool..com/kws/" target="_blank">关键词查询</a> 
        <a href="http://link..com/" target="_blank">友情链接</a> 
        <a href="http://tool..com/map.aspx" class="col-hint" target="_blank">更多工具</a>
    </div>
        <div class="arr"></div>
  </div>
</div>
</body>
</html>