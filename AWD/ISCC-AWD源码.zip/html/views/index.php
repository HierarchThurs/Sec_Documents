<html>
{chinaz:header}

<!--ToolMain02-begin-->
<div class="wrapper"> 
    <div class="wwlr auto">
    <form>
        <!--GuoLvWrap-begin--> 
   		<div class="clearfix">
            <div class="pr JsTxtW-r fl">
		        <textarea class="JsTxtCo bor-a1s h200 WrapHid wwlr-l" id="txtInitCode"></textarea></div>
            <div class="pr JsTxtW-r ml20 fl">
            <div class="JsTxtCo h200 autohide pa" style=" top:0;left:0; line-height:200px; text-align:center" id="loading">正在解析<img src="static/images/loader.gif" /></div>

     </div>


        <!--GuoLvWrap-end-->
    </form>
    </div>
</div>
<!--ToolMain02-end-->

{chinaz:footer}