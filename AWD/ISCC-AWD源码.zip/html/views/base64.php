<html>
{chinaz:header}

<!--ToolMain02-begin-->
<div class="wrapper wwlr">  
    <form method="post">
        <!--GuoLvWrap-begin--> 
        <div class="clearfix">
            <div class="pr JsTxtW-r fl">
                <textarea class="JsTxtCo bor-a1s h200 WrapHid wwlr-l" id="content" name="content"></textarea>
            </div>
        </div>
            <div class="GuoLvWrapCenter ptb10 clearfix">
            <div class="GuoLvCbtn">
            </div>
          </div>

        <!--GuoLvWrap-end-->
    </form> 
</div>
<!--ToolMain02-end-->



{chinaz:footer}