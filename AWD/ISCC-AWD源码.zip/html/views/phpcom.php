<html>
{chinaz:header}

<!--ToolMain02-begin-->
<div class="wrapper"> 
    <div class="wwlr auto">
    <form id="phpcom" method="POST" action="action.php">
        <!--GuoLvWrap-begin--> 
   		<div class="clearfix">
            <div class="pr JsTxtW-r fl">
		        <textarea form="phpcom" name="source" class="JsTxtCo bor-a1s h200 WrapHid wwlr-l" id="txtInitCode"></textarea> </div>
            <div class="pr JsTxtW-r ml20 fl">
            <div class="JsTxtCo h200 autohide pa" style=" top:0;left:0; line-height:200px; text-align:center" id="loading">正在解析<img src="http://cdn..com/tools/images/public/loader.gif" /></div>
           <input type="hidden" name="page" value="phpcom" />
     </div>
        

        <!--GuoLvWrap-end-->
    </form>
    </div>
</div>
<script>    hcj.jstool.init('http://cdn..com/tools/images','7KutWgYPLyOk18Cbz2L9K817XbENwcVH');</script>
<!--ToolMain02-end-->

{chinaz:footer}