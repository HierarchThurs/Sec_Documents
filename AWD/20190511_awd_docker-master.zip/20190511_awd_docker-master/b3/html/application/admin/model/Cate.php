<?php
namespace app\admin\model;
use think\Model;
class Cate extends Model
{





}
