<?php

//require_once "log1.php";
define("DBHOST","localhost");
define('DBUSER','root');
define('DBPASS','334cc35b3c704593');
define('DBNAME','geez');
define('ROOTDRI',__DIR__."/../");

require(ROOTDRI.'/org/smarty/Smarty.class.php');

session_start();

?>
